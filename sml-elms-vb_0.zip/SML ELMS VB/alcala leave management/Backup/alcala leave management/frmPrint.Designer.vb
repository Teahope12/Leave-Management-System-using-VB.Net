﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrint
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer
        Me.tblleavesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.elmsDataSet = New alcala_leave_management.elmsDataSet
        Me.tblleavesTableAdapter = New alcala_leave_management.elmsDataSetTableAdapters.tblleavesTableAdapter
        CType(Me.tblleavesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.elmsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "elmsDataSet_tblleaves"
        ReportDataSource1.Value = Me.tblleavesBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "alcala_leave_management.LEAVE REPORTS.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(687, 507)
        Me.ReportViewer1.TabIndex = 0
        '
        'tblleavesBindingSource
        '
        Me.tblleavesBindingSource.DataMember = "tblleaves"
        Me.tblleavesBindingSource.DataSource = Me.elmsDataSet
        '
        'elmsDataSet
        '
        Me.elmsDataSet.DataSetName = "elmsDataSet"
        Me.elmsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'tblleavesTableAdapter
        '
        Me.tblleavesTableAdapter.ClearBeforeFill = True
        '
        'frmPrint
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(687, 507)
        Me.Controls.Add(Me.ReportViewer1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPrint"
        Me.Text = "frmPrint"
        CType(Me.tblleavesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.elmsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents tblleavesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents elmsDataSet As alcala_leave_management.elmsDataSet
    Friend WithEvents tblleavesTableAdapter As alcala_leave_management.elmsDataSetTableAdapters.tblleavesTableAdapter
End Class
