﻿Imports MySql.Data.MySqlClient

Public Class approvelvfrm

    Private Sub approvelvfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        GroupBox1.Enabled = False
        GroupBox2.Enabled = False
        load_data()
    End Sub
    Public Sub load_info()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"

        Dim comm As New MySqlCommand("select * from tblemployees where EmpId='" & TextBox2.Text & "' ", conn)

        comm.Parameters.Add(" '" & TextBox2.Text & "' ", MySqlDbType.Int64).Value = TextBox2.Text
        Dim adt As New MySqlDataAdapter(comm)

        Dim table As New DataTable()
        adt.Fill(table)

        TextBox3.Text = table.Rows(0)(2).ToString()
        Label10.Text = table.Rows(0)(13).ToString()

    End Sub
    Private Sub load_data()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        Dim query As String
        query = "SELECT `id` as 'ID', `LeaveType` as 'LEAVE TYPE', `Days_of_Leave` as 'DAYS OF LEAVE', `ToDate` as 'TO DATE', `FromDate` as 'FROM DATE', `Description` as 'DESCRIPTION', `PostingDate` as 'POSTING DATE',`Status` as 'STATUS',`EmployeeName` as 'EMPLOYEE NAME', `EmployeeId` as 'EMPLOYEE ID' FROM `tblleaves` WHERE `Status` = 'APPROVE' "



        Try
            conn.Open()


            Dim search As New MySqlDataAdapter(query, conn)
            Dim ds As New DataSet
            search.Fill(ds, "tblleaves")
            DataGridView1.DataSource = ds.Tables("tblleaves")




            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        Finally
            conn.Dispose()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = Me.DataGridView1.Rows(e.RowIndex)

            Label7.Text = row.Cells("DAYS OF LEAVE").Value.ToString
            ComboBox1.Text = row.Cells("LEAVE TYPE").Value.ToString
            DateTimePicker2.Text = row.Cells("TO DATE").Value.ToString
            DateTimePicker1.Text = row.Cells("FROM DATE").Value.ToString
            TextBox1.Text = row.Cells("DESCRIPTION").Value.ToString

            TextBox2.Text = row.Cells("EMPLOYEE ID").Value.ToString


        End If
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        load_info()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub
End Class