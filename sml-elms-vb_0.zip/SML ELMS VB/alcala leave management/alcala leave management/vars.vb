﻿Imports MySql.Data.MySqlClient

Module vars

    Public conn As MySqlConnection
    Public publictable As New DataTable
    Public publictable1 As New DataTable



    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public usertype, email, empid As String
    Public usertype2, email2, empid2 As String
    Public conn2 As MySqlConnection
    Public publictable2 As New DataTable
    Public cmd2 As New MySqlCommand
    Public da2 As New MySqlDataAdapter


    

   


End Module
