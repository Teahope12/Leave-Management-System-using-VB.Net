﻿Imports MySql.Data.MySqlClient
Public Class Emplogfrm
    Dim cmd2 As New MySqlCommand
    Dim da2 As New MySqlDataAdapter
    Dim conn2 As MySqlConnection
    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim sql2 As String
        conn2 = New MySqlConnection
        conn2.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        cmd2 = New MySqlCommand

        Try
            If TextBox1.Text = "" Then
                MsgBox("fill all form")
            Else
                sql2 = "select * from `tblemployees` where EmpId = '" & TextBox1.Text & "'  "

                With cmd2
                    .Connection = conn2
                    .CommandText = sql2

                End With
                da2.SelectCommand = cmd2
                da2.Fill(publictable1)
                If publictable1.Rows.Count > 0 Then

                    empid2 = publictable1.Rows(0).Item(1)
                    usertype2 = publictable1.Rows(0).Item(12)

                End If

                If usertype2 = "user" Then
                    MsgBox(" WELCOME " & empid2 & " HAPPY LEAVE ")
                    TextBox1.Text = ""
                    employee.Show()
                    Me.Close()




                Else
                    MsgBox("CONTACT ADMIN")
                End If
                End If
        Catch ex As Exception

        End Try

       
    End Sub
End Class