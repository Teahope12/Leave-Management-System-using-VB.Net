﻿Imports MySql.Data.MySqlClient
Public Class reportfrm
    Private Sub reportfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_data()
        CheckBox1.Checked = True
        



    End Sub
    Private Sub load2_data()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        Dim query As String
        query = "SELECT `id` as 'ID', `LeaveType` as 'LEAVE TYPE', `Days_of_Leave` as 'DAYS OF LEAVE', `ToDate` as 'TO DATE', `FromDate` as 'FROM DATE', `Description` as 'DESCRIPTION', `PostingDate` as 'POSTING DATE',`Status` as 'STATUS',`EmployeeName` as 'EMPLOYEE NAME', `EmployeeId` as 'EMPLOYEE ID' FROM `tblleaves` WHERE `Status`='REJECT' "



        Try
            conn.Open()


            Dim search As New MySqlDataAdapter(query, conn)
            Dim ds As New DataSet
            search.Fill(ds, "tblleaves")
            DataGridView1.DataSource = ds.Tables("tblleaves")




            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        Finally
            conn.Dispose()
        End Try
    End Sub
    Private Sub load1_data()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        Dim query As String
        query = "SELECT `id` as 'ID', `LeaveType` as 'LEAVE TYPE', `Days_of_Leave` as 'DAYS OF LEAVE', `ToDate` as 'TO DATE', `FromDate` as 'FROM DATE', `Description` as 'DESCRIPTION', `PostingDate` as 'POSTING DATE',`Status` as 'STATUS',`EmployeeName` as 'EMPLOYEE NAME', `EmployeeId` as 'EMPLOYEE ID' FROM `tblleaves` WHERE `Status`='APPROVE' "



        Try
            conn.Open()


            Dim search As New MySqlDataAdapter(query, conn)
            Dim ds As New DataSet
            search.Fill(ds, "tblleaves")
            DataGridView1.DataSource = ds.Tables("tblleaves")




            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        Finally
            conn.Dispose()
        End Try
    End Sub
    Private Sub load_data()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        Dim query As String
        query = "SELECT `id` as 'ID', `LeaveType` as 'LEAVE TYPE', `Days_of_Leave` as 'DAYS OF LEAVE', `ToDate` as 'TO DATE', `FromDate` as 'FROM DATE', `Description` as 'DESCRIPTION', `PostingDate` as 'POSTING DATE',`Status` as 'STATUS',`EmployeeName` as 'EMPLOYEE NAME', `EmployeeId` as 'EMPLOYEE ID' FROM `tblleaves` "



        Try
            conn.Open()


            Dim search As New MySqlDataAdapter(query, conn)
            Dim ds As New DataSet
            search.Fill(ds, "tblleaves")
            DataGridView1.DataSource = ds.Tables("tblleaves")




            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        Finally
            conn.Dispose()
        End Try
    End Sub
    

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged


        If CheckBox2.Checked = True Then
            CheckBox1.Checked = False
            CheckBox3.Checked = False
            load1_data()



        End If

        If CheckBox3.Checked = False And CheckBox2.Checked = False Then
            CheckBox1.Checked = True

        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged


        If CheckBox3.Checked = True Then
            CheckBox1.Checked = False
            CheckBox2.Checked = False
            load2_data()

        End If
        If CheckBox3.Checked = False And CheckBox2.Checked = False Then
            CheckBox1.Checked = True

        End If

    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        load_data()

        If CheckBox1.Checked = True Then
            CheckBox2.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub
   
   
   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        If CheckBox1.Checked = True Then
            frmPrint.Show()
            Me.Hide()
        ElseIf CheckBox2.Checked = True Then
            Frmprintapprove.Show()
            Me.Hide()
        Else
            Frmprintreject.Show()
            Me.Hide()


        End If


    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        If CheckBox1.Checked = True Then
            frmPrint.Show()
            Me.Hide()
        ElseIf CheckBox2.Checked = True Then
            Frmprintapprove.Show()
            Me.Hide()
        Else
            Frmprintreject.Show()
            Me.Hide()


        End If

    End Sub
End Class