﻿Imports MySql.Data.MySqlClient

Public Class newloginfrm
    Dim cmd As New MySqlCommand
    Dim da As New MySqlDataAdapter
    Dim conn As MySqlConnection
    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim sql As String
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"
        cmd = New MySqlCommand


        Try
            If TextBox2.Text = "" And TextBox3.Text = "" And TextBox1.Text = "" Then
                MsgBox("fill all forms")
            Else
                sql = "select * from `tblacc` where empid = '" & TextBox1.Text & "' and email= '" & TextBox2.Text & "' and password= '" & TextBox3.Text & "' "

                With cmd
                    .Connection = conn
                    .CommandText = sql
                End With
                da.SelectCommand = cmd
                da.Fill(publictable)
                If publictable.Rows.Count > 0 Then

                    empid = publictable.Rows(0).Item(1)
                    email = publictable.Rows(0).Item(2)
                    usertype = publictable.Rows(0).Item(4)

                   

                    If usertype = "admin" Or usertype = "manager" Or usertype = "co-manager" Or usertype = "boss" Then
                        MsgBox(" WELCOME " & email & " HAVE A NICE DAY")



                        GroupBox1.Enabled = False
                        TextBox2.Text = ""
                        TextBox3.Text = ""
                        TextBox1.Text = ""
                        main_frm.Show()
                        Me.Close()

                    Else

                    End If
                Else
                    MsgBox("contact admin")
                    TextBox2.Text = ""
                    TextBox3.Text = ""
                    TextBox1.Text = ""

                End If

                da.Dispose()

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()

        End Try
    End Sub

   
End Class