﻿Imports MySql.Data.MySqlClient

Public Class applyleave
    Dim a, b, c As String


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        conn = New MySqlConnection
        Dim result As Integer
        Dim cmd As New MySqlCommand

        
        a = Label10.Text
        b = Label7.Text
        c = a - b
        Label13.Text = c
       
        If TextBox2.Text = "" Or Label7.Text = 0 Or Label13.Text < 0 Then
            MessageBox.Show("fill all the form and Check Leave days")


        Else

            conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"

            Try
                conn.Open()
                With cmd


                    .Connection = conn
                    .CommandText = "INSERT INTO `tblleaves`(`LeaveType`, `Days_of_Leave`, `ToDate`, `FromDate`,`PostingDate`, `Description`, `EmployeeName`, `EmployeeId`,`Status`,`ShiftTime`) VALUES  ('" & ComboBox1.Text & "','" & Label7.Text & "','" & DateTimePicker2.Text & "','" & DateTimePicker1.Text & "','" & DateTimePicker3.Text & "','" & TextBox1.Text & "','" & TextBox3.Text & "','" & TextBox2.Text & "','" & Label17.Text & "','" & ComboBox2.Text & "')"

                    result = .ExecuteNonQuery



                    MessageBox.Show("Apply Success")


                End With




                conn.Close()

            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            Finally
                conn.Dispose()
            End Try
        End If
    End Sub

    Private Sub applyleave_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If usertype2 = "user" Then

            TextBox2.Text = "" & empid2
        End If

       cb1_load()
        GroupBox1.Enabled = False
        load_info()




        
    End Sub
   
   Public Sub cb1_load()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"


        Dim str As String
        conn.Open()


        Try
            str = "SELECT `LeaveType` FROM `tblleaveType` GROUP by `LeaveType` "
            Dim da As New MySqlDataAdapter(str, conn)
            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                ComboBox1.DataSource = dt
                ComboBox1.DisplayMember = "LeaveType"
                ComboBox1.ValueMember = ""

            End If

        Catch ex As Exception

        End Try

    End Sub
   
    Public Sub load_info()
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=elms"

        Dim comm As New MySqlCommand("select * from tblemployees where EmpId='" & TextBox2.Text & "' ", conn)

        comm.Parameters.Add(" '" & TextBox2.Text & "' ", MySqlDbType.Int64).Value = TextBox2.Text
        Dim adt As New MySqlDataAdapter(comm)

        Dim table As New DataTable()
        adt.Fill(table)

        TextBox3.Text = table.Rows(0)(2).ToString()
        Label10.Text = table.Rows(0)(13).ToString()

    End Sub


    Private Sub DateTimePicker2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker2.ValueChanged
        Dim borrow As DateTime = Convert.ToDateTime(DateTimePicker1.Text)
        Dim back As DateTime = Convert.ToDateTime(DateTimePicker2.Text)
        Dim countdays As TimeSpan = back.Subtract(borrow)
        Dim days = Convert.ToInt32(countdays.Days)



        If Convert.ToInt32(countdays.Days) >= 0 Then
            Label7.Text = days
        Else
            MsgBox("checked date again")
        End If

        If ComboBox2.Text = "AM" Then
           

            If Convert.ToInt32(countdays.Days) >= 0 Then
                Label7.Text = days
            Else
                MsgBox("checked date again")
            End If

            a = Label7.Text

            c = a / 2
            Label7.Text = c


        ElseIf ComboBox2.Text = "PM" Then
           



            If Convert.ToInt32(countdays.Days) >= 0 Then
                Label7.Text = days
            Else
                MsgBox("checked date again")
            End If
            a = Label7.Text

            c = a / 2
            Label7.Text = c


        End If
    End Sub

   
    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.Text = "AM" Then
            Dim borrow As DateTime = Convert.ToDateTime(DateTimePicker1.Text)
            Dim back As DateTime = Convert.ToDateTime(DateTimePicker2.Text)
            Dim countdays As TimeSpan = back.Subtract(borrow)
            Dim days = Convert.ToInt32(countdays.Days)



            If Convert.ToInt32(countdays.Days) >= 0 Then
                Label7.Text = days
            Else
                MsgBox("checked date again")
            End If

            a = Label7.Text

            c = a / 2
            Label7.Text = c
            

        ElseIf ComboBox2.Text = "PM" Then
            Dim borrow As DateTime = Convert.ToDateTime(DateTimePicker1.Text)
            Dim back As DateTime = Convert.ToDateTime(DateTimePicker2.Text)
            Dim countdays As TimeSpan = back.Subtract(borrow)
            Dim days = Convert.ToInt32(countdays.Days)



            If Convert.ToInt32(countdays.Days) >= 0 Then
                Label7.Text = days
            Else
                MsgBox("checked date again")
            End If
            a = Label7.Text

            c = a / 2
            Label7.Text = c
        Else
            Dim borrow As DateTime = Convert.ToDateTime(DateTimePicker1.Text)
            Dim back As DateTime = Convert.ToDateTime(DateTimePicker2.Text)
            Dim countdays As TimeSpan = back.Subtract(borrow)
            Dim days = Convert.ToInt32(countdays.Days)



            If Convert.ToInt32(countdays.Days) >= 0 Then
                Label7.Text = days
            Else
                MsgBox("checked date again")
            End If
        End If

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class