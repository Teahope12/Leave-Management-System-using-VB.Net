﻿Partial Class elmsDataSet1
    Partial Class DataTable1DataTable

        Private Sub DataTable1DataTable_DataTable1RowChanging(ByVal sender As System.Object, ByVal e As DataTable1RowChangeEvent) Handles Me.DataTable1RowChanging

        End Sub

    End Class

End Class

Namespace elmsDataSet1TableAdapters
    
    Partial Public Class DataTable1TableAdapter
    End Class
End Namespace
