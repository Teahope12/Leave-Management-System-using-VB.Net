﻿Public Class frmPrint

    Private Sub frmPrint_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'elmsDataSet.tblleaves' table. You can move, or remove it, as needed.
        Me.tblleavesTableAdapter.Fill(Me.elmsDataSet.tblleaves)

        Me.ReportViewer1.RefreshReport()
    End Sub

    
End Class