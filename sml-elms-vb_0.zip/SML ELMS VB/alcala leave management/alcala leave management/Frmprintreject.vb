﻿Public Class Frmprintreject

    Private Sub Frmprintreject_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'elmsDataSet2.DataTable1' table. You can move, or remove it, as needed.
        Me.DataTable1TableAdapter.Fill(Me.elmsDataSet2.DataTable1)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class