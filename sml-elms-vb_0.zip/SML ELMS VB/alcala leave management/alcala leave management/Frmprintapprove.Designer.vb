﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmprintapprove
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim ReportDataSource2 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer
        Me.ElmsDataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ElmsDataSet1 = New alcala_leave_management.elmsDataSet1
        Me.elmsDataSet = New alcala_leave_management.elmsDataSet
        Me.tblleavesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.tblleavesTableAdapter = New alcala_leave_management.elmsDataSetTableAdapters.tblleavesTableAdapter
        Me.DataTable1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataTable1TableAdapter = New alcala_leave_management.elmsDataSet1TableAdapters.DataTable1TableAdapter
        CType(Me.ElmsDataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ElmsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.elmsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tblleavesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource2.Name = "elmsDataSet1_DataTable1"
        ReportDataSource2.Value = Me.DataTable1BindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource2)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "alcala_leave_management.LEAVE APPROVE REPORTS.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(687, 507)
        Me.ReportViewer1.TabIndex = 0
        '
        'ElmsDataSet1BindingSource
        '
        Me.ElmsDataSet1BindingSource.DataSource = Me.ElmsDataSet1
        Me.ElmsDataSet1BindingSource.Position = 0
        '
        'ElmsDataSet1
        '
        Me.ElmsDataSet1.DataSetName = "elmsDataSet1"
        Me.ElmsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'elmsDataSet
        '
        Me.elmsDataSet.DataSetName = "elmsDataSet"
        Me.elmsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'tblleavesBindingSource
        '
        Me.tblleavesBindingSource.DataMember = "tblleaves"
        Me.tblleavesBindingSource.DataSource = Me.elmsDataSet
        '
        'tblleavesTableAdapter
        '
        Me.tblleavesTableAdapter.ClearBeforeFill = True
        '
        'DataTable1BindingSource
        '
        Me.DataTable1BindingSource.DataMember = "DataTable1"
        Me.DataTable1BindingSource.DataSource = Me.ElmsDataSet1
        '
        'DataTable1TableAdapter
        '
        Me.DataTable1TableAdapter.ClearBeforeFill = True
        '
        'Frmprintapprove
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(687, 507)
        Me.Controls.Add(Me.ReportViewer1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frmprintapprove"
        Me.Text = "Frmprintapprove"
        CType(Me.ElmsDataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ElmsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.elmsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tblleavesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents tblleavesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents elmsDataSet As alcala_leave_management.elmsDataSet
    Friend WithEvents tblleavesTableAdapter As alcala_leave_management.elmsDataSetTableAdapters.tblleavesTableAdapter
    Friend WithEvents ElmsDataSet1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ElmsDataSet1 As alcala_leave_management.elmsDataSet1
    Friend WithEvents DataTable1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataTable1TableAdapter As alcala_leave_management.elmsDataSet1TableAdapters.DataTable1TableAdapter
End Class
