﻿Partial Class elmsDataSet
End Class

Namespace elmsDataSetTableAdapters
    
    Partial Public Class tblleavesTableAdapter
    End Class
End Namespace
