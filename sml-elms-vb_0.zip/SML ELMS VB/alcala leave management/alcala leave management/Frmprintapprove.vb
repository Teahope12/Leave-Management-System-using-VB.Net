﻿Public Class Frmprintapprove

    Private Sub Frmprintapprove_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ElmsDataSet1.DataTable1' table. You can move, or remove it, as needed.
        Me.DataTable1TableAdapter.Fill(Me.ElmsDataSet1.DataTable1)
        'TODO: This line of code loads data into the 'elmsDataSet.tblleaves' table. You can move, or remove it, as needed.
        Me.tblleavesTableAdapter.Fill(Me.elmsDataSet.tblleaves)

        Me.ReportViewer1.RefreshReport()
        Me.ReportViewer1.RefreshReport()
    End Sub
End Class